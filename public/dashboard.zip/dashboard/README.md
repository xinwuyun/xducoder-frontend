# Dashboard template

## Usage

Simply copy the files into your project, or one of the [example applications](https://github.com/mui-org/material-ui/tree/master/examples), and import and use the `Dashboard` component.

## Demo

View the demo at https://material-ui.com/getting-started/templates/dashboard/.
